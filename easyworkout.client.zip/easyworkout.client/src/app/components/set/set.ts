import { Component } from '@angular/core';

@Component({
  selector: 'app-set',
  imports: [],
  templateUrl: './set.html',
  styleUrl: './set.css',
})
export class Set {

}
